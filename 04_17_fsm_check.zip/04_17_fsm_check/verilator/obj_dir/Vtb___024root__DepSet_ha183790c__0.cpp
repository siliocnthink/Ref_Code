// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtb.h for the primary calling header

#include "Vtb__pch.h"
#include "Vtb___024root.h"

VlCoroutine Vtb___024root___eval_initial__TOP__Vtiming__0(Vtb___024root* vlSelf);
VlCoroutine Vtb___024root___eval_initial__TOP__Vtiming__1(Vtb___024root* vlSelf);
VlCoroutine Vtb___024root___eval_initial__TOP__Vtiming__2(Vtb___024root* vlSelf);

void Vtb___024root___eval_initial(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_initial\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vm_traceActivity[1U] = 1U;
    Vtb___024root___eval_initial__TOP__Vtiming__0(vlSelf);
    Vtb___024root___eval_initial__TOP__Vtiming__1(vlSelf);
    Vtb___024root___eval_initial__TOP__Vtiming__2(vlSelf);
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWtmp_hf6f3e5e5__0__0 
        = vlSelfRef.__VassignWtmp_hf6f3e5e5__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWgen_hf9bb11f4__0__0 
        = vlSelfRef.__VassignWgen_hf9bb11f4__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWtmp_he94c6eea__0__0 
        = vlSelfRef.__VassignWtmp_he94c6eea__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWgen_hc411ff4f__0__0 
        = vlSelfRef.__VassignWgen_hc411ff4f__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWtmp_h6f72e14a__0__0 
        = vlSelfRef.__VassignWtmp_h6f72e14a__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWgen_h05137648__0__0 
        = vlSelfRef.__VassignWgen_h05137648__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWtmp_hf6f3e5e5__0__1 
        = vlSelfRef.__VassignWtmp_hf6f3e5e5__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWgen_hf9bb11f4__0__1 
        = vlSelfRef.__VassignWgen_hf9bb11f4__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWtmp_he94c6eea__0__1 
        = vlSelfRef.__VassignWtmp_he94c6eea__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWgen_hc411ff4f__0__1 
        = vlSelfRef.__VassignWgen_hc411ff4f__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWtmp_h6f72e14a__0__1 
        = vlSelfRef.__VassignWtmp_h6f72e14a__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWgen_h05137648__0__1 
        = vlSelfRef.__VassignWgen_h05137648__0;
    vlSelfRef.__Vtrigprevexpr___TOP__tb__DOT__clk__0 
        = vlSelfRef.tb__DOT__clk;
    vlSelfRef.__Vtrigprevexpr___TOP__tb__DOT__rstn__0 
        = vlSelfRef.tb__DOT__rstn;
}

VL_INLINE_OPT VlCoroutine Vtb___024root___eval_initial__TOP__Vtiming__1(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_initial__TOP__Vtiming__1\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    while (1U) {
        co_await vlSelfRef.__VdlySched.delay(0x32ULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             40);
        vlSelfRef.tb__DOT__clk = (1U & (~ (IData)(vlSelfRef.tb__DOT__clk)));
    }
}

VL_INLINE_OPT VlCoroutine Vtb___024root___eval_initial__TOP__Vtiming__2(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_initial__TOP__Vtiming__2\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    while (1U) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             128);
        if (VL_UNLIKELY(((IData)(vlSelfRef.tb__DOT__cmp_time) 
                         & ((IData)(vlSelfRef.tb__DOT__chk_sta_buf) 
                            != (IData)(vlSelfRef.tb__DOT__ref_sta_buf))))) {
            VL_WRITEF_NX("Sim Failed.\n",0);
            co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                                 nullptr, 
                                                                 "@(posedge tb.clk)", 
                                                                 "../pattern/tb.v", 
                                                                 131);
            VL_FINISH_MT("../pattern/tb.v", 132, "");
        }
    }
}

void Vtb___024root___act_comb__TOP__0(Vtb___024root* vlSelf);
void Vtb___024root___act_sequent__TOP__0(Vtb___024root* vlSelf);
void Vtb___024root___act_comb__TOP__1(Vtb___024root* vlSelf);
void Vtb___024root___act_comb__TOP__2(Vtb___024root* vlSelf);

void Vtb___024root___eval_act(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_act\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((0x143ULL & vlSelfRef.__VactTriggered.word(0U))) {
        Vtb___024root___act_comb__TOP__0(vlSelf);
    }
    if ((0xcULL & vlSelfRef.__VactTriggered.word(0U))) {
        Vtb___024root___act_sequent__TOP__0(vlSelf);
    }
    if ((0x140ULL & vlSelfRef.__VactTriggered.word(0U))) {
        Vtb___024root___act_comb__TOP__1(vlSelf);
    }
    if ((0x170ULL & vlSelfRef.__VactTriggered.word(0U))) {
        Vtb___024root___act_comb__TOP__2(vlSelf);
    }
}

VlCoroutine Vtb___024root___act_comb__TOP__0____Vfork_1__0(Vtb___024root* vlSelf);

VL_INLINE_OPT void Vtb___024root___act_comb__TOP__0(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___act_comb__TOP__0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.tb__DOT__din) != (IData)(vlSelfRef.__VassignWtmp_hf6f3e5e5__0))) {
        Vtb___024root___act_comb__TOP__0____Vfork_1__0(vlSelf);
    }
}

VL_INLINE_OPT VlCoroutine Vtb___024root___act_comb__TOP__0____Vfork_1__0(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___act_comb__TOP__0____Vfork_1__0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __Vintraval_hd11cca34__0;
    __Vintraval_hd11cca34__0 = 0;
    // Body
    QData/*63:0*/ __VassignWgen_hf9bb11f4__0__local;
    __VassignWgen_hf9bb11f4__0__local = 0;
    vlSelfRef.__VassignWgen_hf9bb11f4__0 = ((QData)((IData)(1U)) 
                                            + vlSelfRef.__VassignWgen_hf9bb11f4__0);
    __VassignWgen_hf9bb11f4__0__local = vlSelfRef.__VassignWgen_hf9bb11f4__0;
    __Vintraval_hd11cca34__0 = vlSelfRef.tb__DOT__din;
    vlSelfRef.__VassignWtmp_hf6f3e5e5__0 = __Vintraval_hd11cca34__0;
    co_await vlSelfRef.__VdlySched.delay(1ULL, nullptr, 
                                         "../pattern/tb.v", 
                                         43);
    if ((vlSelfRef.__VassignWgen_hf9bb11f4__0 == __VassignWgen_hf9bb11f4__0__local)) {
        vlSelfRef.tb__DOT__din_buf = __Vintraval_hd11cca34__0;
    }
}

VlCoroutine Vtb___024root___act_sequent__TOP__0____Vfork_2__0(Vtb___024root* vlSelf);

VL_INLINE_OPT void Vtb___024root___act_sequent__TOP__0(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___act_sequent__TOP__0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.tb__DOT__chk_sta) != (IData)(vlSelfRef.__VassignWtmp_he94c6eea__0))) {
        Vtb___024root___act_sequent__TOP__0____Vfork_2__0(vlSelf);
    }
}

VL_INLINE_OPT VlCoroutine Vtb___024root___act_sequent__TOP__0____Vfork_2__0(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___act_sequent__TOP__0____Vfork_2__0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __Vintraval_hddcfb641__0;
    __Vintraval_hddcfb641__0 = 0;
    // Body
    QData/*63:0*/ __VassignWgen_hc411ff4f__0__local;
    __VassignWgen_hc411ff4f__0__local = 0;
    vlSelfRef.__VassignWgen_hc411ff4f__0 = ((QData)((IData)(1U)) 
                                            + vlSelfRef.__VassignWgen_hc411ff4f__0);
    __VassignWgen_hc411ff4f__0__local = vlSelfRef.__VassignWgen_hc411ff4f__0;
    __Vintraval_hddcfb641__0 = vlSelfRef.tb__DOT__chk_sta;
    vlSelfRef.__VassignWtmp_he94c6eea__0 = __Vintraval_hddcfb641__0;
    co_await vlSelfRef.__VdlySched.delay(1ULL, nullptr, 
                                         "../pattern/tb.v", 
                                         44);
    if ((vlSelfRef.__VassignWgen_hc411ff4f__0 == __VassignWgen_hc411ff4f__0__local)) {
        vlSelfRef.tb__DOT__chk_sta_buf = __Vintraval_hddcfb641__0;
    }
}

VL_INLINE_OPT void Vtb___024root___act_comb__TOP__1(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___act_comb__TOP__1\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.tb__DOT__ref_sta__VforceRd = ((IData)(vlSelfRef.tb__DOT__ref_sta__VforceEn)
                                             ? (IData)(vlSelfRef.tb__DOT__ref_sta__VforceVal)
                                             : (IData)(vlSelfRef.tb__DOT__ref_sta));
}

VlCoroutine Vtb___024root___act_comb__TOP__2____Vfork_3__0(Vtb___024root* vlSelf);

VL_INLINE_OPT void Vtb___024root___act_comb__TOP__2(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___act_comb__TOP__2\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.tb__DOT__ref_sta__VforceRd) 
         != (IData)(vlSelfRef.__VassignWtmp_h6f72e14a__0))) {
        Vtb___024root___act_comb__TOP__2____Vfork_3__0(vlSelf);
    }
}

VL_INLINE_OPT VlCoroutine Vtb___024root___act_comb__TOP__2____Vfork_3__0(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___act_comb__TOP__2____Vfork_3__0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __Vintraval_hdf863420__0;
    __Vintraval_hdf863420__0 = 0;
    // Body
    QData/*63:0*/ __VassignWgen_h05137648__0__local;
    __VassignWgen_h05137648__0__local = 0;
    vlSelfRef.__VassignWgen_h05137648__0 = ((QData)((IData)(1U)) 
                                            + vlSelfRef.__VassignWgen_h05137648__0);
    __VassignWgen_h05137648__0__local = vlSelfRef.__VassignWgen_h05137648__0;
    __Vintraval_hdf863420__0 = vlSelfRef.tb__DOT__ref_sta__VforceRd;
    vlSelfRef.__VassignWtmp_h6f72e14a__0 = __Vintraval_hdf863420__0;
    co_await vlSelfRef.__VdlySched.delay(1ULL, nullptr, 
                                         "../pattern/tb.v", 
                                         45);
    if ((vlSelfRef.__VassignWgen_h05137648__0 == __VassignWgen_h05137648__0__local)) {
        vlSelfRef.tb__DOT__ref_sta_buf = __Vintraval_hdf863420__0;
    }
}

void Vtb___024root___nba_sequent__TOP__0(Vtb___024root* vlSelf);

void Vtb___024root___eval_nba(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_nba\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((0xc0ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        Vtb___024root___nba_sequent__TOP__0(vlSelf);
        vlSelfRef.__Vm_traceActivity[3U] = 1U;
    }
    if ((0xccULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        Vtb___024root___act_sequent__TOP__0(vlSelf);
    }
}

VL_INLINE_OPT void Vtb___024root___nba_sequent__TOP__0(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___nba_sequent__TOP__0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*2:0*/ __Vdly__tb__DOT__u_fsm_chk__DOT__sta;
    __Vdly__tb__DOT__u_fsm_chk__DOT__sta = 0;
    CData/*6:0*/ __Vdly__tb__DOT__u_fsm_chk__DOT__tcnt;
    __Vdly__tb__DOT__u_fsm_chk__DOT__tcnt = 0;
    CData/*3:0*/ __Vdly__tb__DOT__u_fsm_chk__DOT__ccnt;
    __Vdly__tb__DOT__u_fsm_chk__DOT__ccnt = 0;
    // Body
    __Vdly__tb__DOT__u_fsm_chk__DOT__sta = vlSelfRef.tb__DOT__u_fsm_chk__DOT__sta;
    __Vdly__tb__DOT__u_fsm_chk__DOT__tcnt = vlSelfRef.tb__DOT__u_fsm_chk__DOT__tcnt;
    __Vdly__tb__DOT__u_fsm_chk__DOT__ccnt = vlSelfRef.tb__DOT__u_fsm_chk__DOT__ccnt;
    if (vlSelfRef.tb__DOT__rstn) {
        if ((4U & (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__sta))) {
            if ((2U & (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__sta))) {
                __Vdly__tb__DOT__u_fsm_chk__DOT__sta 
                    = ((1U & (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__sta))
                        ? 0U : 6U);
            } else if ((1U & (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__sta))) {
                __Vdly__tb__DOT__u_fsm_chk__DOT__tcnt = 0U;
                if ((0xfU == (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__tcnt))) {
                    __Vdly__tb__DOT__u_fsm_chk__DOT__ccnt = 0U;
                    if (vlSelfRef.tb__DOT__din_buf) {
                        __Vdly__tb__DOT__u_fsm_chk__DOT__sta = 4U;
                        vlSelfRef.tb__DOT__chk_sta = 1U;
                    } else {
                        __Vdly__tb__DOT__u_fsm_chk__DOT__sta = 5U;
                    }
                } else {
                    __Vdly__tb__DOT__u_fsm_chk__DOT__tcnt 
                        = (0x7fU & ((IData)(1U) + (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__tcnt)));
                }
            } else {
                if ((0x63U == (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__tcnt))) {
                    __Vdly__tb__DOT__u_fsm_chk__DOT__ccnt 
                        = (0xfU & ((IData)(1U) + (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__ccnt)));
                    vlSelfRef.tb__DOT__chk_sta = 0U;
                }
                if ((0x64U == (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__tcnt))) {
                    __Vdly__tb__DOT__u_fsm_chk__DOT__tcnt = 0U;
                    if (vlSelfRef.tb__DOT__din_buf) {
                        if ((9U == (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__ccnt))) {
                            __Vdly__tb__DOT__u_fsm_chk__DOT__sta = 6U;
                            vlSelfRef.tb__DOT__chk_sta = 1U;
                        } else {
                            __Vdly__tb__DOT__u_fsm_chk__DOT__sta = 4U;
                            vlSelfRef.tb__DOT__chk_sta = 1U;
                        }
                    } else {
                        __Vdly__tb__DOT__u_fsm_chk__DOT__sta = 5U;
                    }
                } else {
                    __Vdly__tb__DOT__u_fsm_chk__DOT__tcnt 
                        = (0x7fU & ((IData)(1U) + (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__tcnt)));
                }
            }
        } else if ((2U & (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__sta))) {
            if ((1U & (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__sta))) {
                if ((0xfU == (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__tcnt))) {
                    __Vdly__tb__DOT__u_fsm_chk__DOT__tcnt = 0U;
                    if (vlSelfRef.tb__DOT__din_buf) {
                        __Vdly__tb__DOT__u_fsm_chk__DOT__sta = 4U;
                        vlSelfRef.tb__DOT__chk_sta = 1U;
                    } else {
                        __Vdly__tb__DOT__u_fsm_chk__DOT__sta = 5U;
                    }
                } else {
                    __Vdly__tb__DOT__u_fsm_chk__DOT__tcnt 
                        = (0x7fU & ((IData)(1U) + (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__tcnt)));
                }
            } else if ((0x63U == (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__tcnt))) {
                __Vdly__tb__DOT__u_fsm_chk__DOT__tcnt = 0U;
                __Vdly__tb__DOT__u_fsm_chk__DOT__sta = 3U;
                vlSelfRef.tb__DOT__chk_sta = 0U;
            } else {
                __Vdly__tb__DOT__u_fsm_chk__DOT__tcnt 
                    = (0x7fU & ((IData)(1U) + (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__tcnt)));
            }
        } else if ((1U & (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__sta))) {
            if ((0xeU == (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__tcnt))) {
                __Vdly__tb__DOT__u_fsm_chk__DOT__tcnt = 0U;
                __Vdly__tb__DOT__u_fsm_chk__DOT__sta = 2U;
                vlSelfRef.tb__DOT__chk_sta = 1U;
            } else {
                __Vdly__tb__DOT__u_fsm_chk__DOT__tcnt 
                    = (0x7fU & ((IData)(1U) + (IData)(vlSelfRef.tb__DOT__u_fsm_chk__DOT__tcnt)));
            }
        } else if (vlSelfRef.tb__DOT__din_buf) {
            __Vdly__tb__DOT__u_fsm_chk__DOT__sta = 1U;
        }
    } else {
        __Vdly__tb__DOT__u_fsm_chk__DOT__tcnt = 0U;
        __Vdly__tb__DOT__u_fsm_chk__DOT__sta = 0U;
        vlSelfRef.tb__DOT__chk_sta = 0U;
        __Vdly__tb__DOT__u_fsm_chk__DOT__ccnt = 0U;
    }
    vlSelfRef.tb__DOT__u_fsm_chk__DOT__sta = __Vdly__tb__DOT__u_fsm_chk__DOT__sta;
    vlSelfRef.tb__DOT__u_fsm_chk__DOT__tcnt = __Vdly__tb__DOT__u_fsm_chk__DOT__tcnt;
    vlSelfRef.tb__DOT__u_fsm_chk__DOT__ccnt = __Vdly__tb__DOT__u_fsm_chk__DOT__ccnt;
}

void Vtb___024root___timing_resume(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___timing_resume\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((0x40ULL & vlSelfRef.__VactTriggered.word(0U))) {
        vlSelfRef.__VtrigSched_h95cd0708__0.resume(
                                                   "@(posedge tb.clk)");
    }
    if ((0x100ULL & vlSelfRef.__VactTriggered.word(0U))) {
        vlSelfRef.__VdlySched.resume();
    }
}

void Vtb___024root___timing_commit(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___timing_commit\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((! (0x40ULL & vlSelfRef.__VactTriggered.word(0U)))) {
        vlSelfRef.__VtrigSched_h95cd0708__0.commit(
                                                   "@(posedge tb.clk)");
    }
}

void Vtb___024root___eval_triggers__act(Vtb___024root* vlSelf);

bool Vtb___024root___eval_phase__act(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_phase__act\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    VlTriggerVec<9> __VpreTriggered;
    CData/*0:0*/ __VactExecute;
    // Body
    Vtb___024root___eval_triggers__act(vlSelf);
    Vtb___024root___timing_commit(vlSelf);
    __VactExecute = vlSelfRef.__VactTriggered.any();
    if (__VactExecute) {
        __VpreTriggered.andNot(vlSelfRef.__VactTriggered, vlSelfRef.__VnbaTriggered);
        vlSelfRef.__VnbaTriggered.thisOr(vlSelfRef.__VactTriggered);
        Vtb___024root___timing_resume(vlSelf);
        Vtb___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Vtb___024root___eval_phase__nba(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_phase__nba\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = vlSelfRef.__VnbaTriggered.any();
    if (__VnbaExecute) {
        Vtb___024root___eval_nba(vlSelf);
        vlSelfRef.__VnbaTriggered.clear();
    }
    return (__VnbaExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb___024root___dump_triggers__nba(Vtb___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb___024root___dump_triggers__act(Vtb___024root* vlSelf);
#endif  // VL_DEBUG

void Vtb___024root___eval(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ __VnbaIterCount;
    CData/*0:0*/ __VnbaContinue;
    // Body
    __VnbaIterCount = 0U;
    __VnbaContinue = 1U;
    while (__VnbaContinue) {
        if (VL_UNLIKELY((0x64U < __VnbaIterCount))) {
#ifdef VL_DEBUG
            Vtb___024root___dump_triggers__nba(vlSelf);
#endif
            VL_FATAL_MT("../pattern/tb.v", 24, "", "NBA region did not converge.");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        __VnbaContinue = 0U;
        vlSelfRef.__VactIterCount = 0U;
        vlSelfRef.__VactContinue = 1U;
        while (vlSelfRef.__VactContinue) {
            if (VL_UNLIKELY((0x64U < vlSelfRef.__VactIterCount))) {
#ifdef VL_DEBUG
                Vtb___024root___dump_triggers__act(vlSelf);
#endif
                VL_FATAL_MT("../pattern/tb.v", 24, "", "Active region did not converge.");
            }
            vlSelfRef.__VactIterCount = ((IData)(1U) 
                                         + vlSelfRef.__VactIterCount);
            vlSelfRef.__VactContinue = 0U;
            if (Vtb___024root___eval_phase__act(vlSelf)) {
                vlSelfRef.__VactContinue = 1U;
            }
        }
        if (Vtb___024root___eval_phase__nba(vlSelf)) {
            __VnbaContinue = 1U;
        }
    }
}

#ifdef VL_DEBUG
void Vtb___024root___eval_debug_assertions(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_debug_assertions\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
}
#endif  // VL_DEBUG
