// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vtb.h for the primary calling header

#ifndef VERILATED_VTB___024ROOT_H_
#define VERILATED_VTB___024ROOT_H_  // guard

#include "verilated.h"
#include "verilated_timing.h"


class Vtb__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vtb___024root final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    CData/*0:0*/ tb__DOT__clk;
    CData/*0:0*/ tb__DOT__rstn;
    CData/*0:0*/ tb__DOT__din;
    CData/*0:0*/ tb__DOT__ref_sta;
    CData/*0:0*/ tb__DOT__ref_sta__VforceRd;
    CData/*0:0*/ tb__DOT__ref_sta__VforceEn;
    CData/*0:0*/ tb__DOT__ref_sta__VforceVal;
    CData/*0:0*/ tb__DOT__chk_sta;
    CData/*0:0*/ tb__DOT__cmp_time;
    CData/*0:0*/ tb__DOT__din_buf;
    CData/*0:0*/ tb__DOT__chk_sta_buf;
    CData/*0:0*/ tb__DOT__ref_sta_buf;
    CData/*2:0*/ tb__DOT__u_fsm_chk__DOT__sta;
    CData/*6:0*/ tb__DOT__u_fsm_chk__DOT__tcnt;
    CData/*3:0*/ tb__DOT__u_fsm_chk__DOT__ccnt;
    CData/*0:0*/ __VassignWtmp_hf6f3e5e5__0;
    CData/*0:0*/ __VassignWtmp_he94c6eea__0;
    CData/*0:0*/ __VassignWtmp_h6f72e14a__0;
    CData/*0:0*/ __Vtrigprevexpr___TOP____VassignWtmp_hf6f3e5e5__0__0;
    CData/*0:0*/ __Vtrigprevexpr___TOP____VassignWtmp_he94c6eea__0__0;
    CData/*0:0*/ __Vtrigprevexpr___TOP____VassignWtmp_h6f72e14a__0__0;
    CData/*0:0*/ __VstlDidInit;
    CData/*0:0*/ __VstlFirstIteration;
    CData/*0:0*/ __Vtrigprevexpr___TOP____VassignWtmp_hf6f3e5e5__0__1;
    CData/*0:0*/ __Vtrigprevexpr___TOP____VassignWtmp_he94c6eea__0__1;
    CData/*0:0*/ __Vtrigprevexpr___TOP____VassignWtmp_h6f72e14a__0__1;
    CData/*0:0*/ __Vtrigprevexpr___TOP__tb__DOT__clk__0;
    CData/*0:0*/ __Vtrigprevexpr___TOP__tb__DOT__rstn__0;
    CData/*0:0*/ __VactDidInit;
    CData/*0:0*/ __VactContinue;
    IData/*31:0*/ tb__DOT__cnt;
    IData/*31:0*/ tb__DOT__dbg;
    IData/*31:0*/ __VactIterCount;
    QData/*63:0*/ __VassignWgen_hf9bb11f4__0;
    QData/*63:0*/ __VassignWgen_hc411ff4f__0;
    QData/*63:0*/ __VassignWgen_h05137648__0;
    QData/*63:0*/ __Vtrigprevexpr___TOP____VassignWgen_hf9bb11f4__0__0;
    QData/*63:0*/ __Vtrigprevexpr___TOP____VassignWgen_hc411ff4f__0__0;
    QData/*63:0*/ __Vtrigprevexpr___TOP____VassignWgen_h05137648__0__0;
    QData/*63:0*/ __Vtrigprevexpr___TOP____VassignWgen_hf9bb11f4__0__1;
    QData/*63:0*/ __Vtrigprevexpr___TOP____VassignWgen_hc411ff4f__0__1;
    QData/*63:0*/ __Vtrigprevexpr___TOP____VassignWgen_h05137648__0__1;
    VlUnpacked<CData/*0:0*/, 4> __Vm_traceActivity;
    VlDelayScheduler __VdlySched;
    VlTriggerScheduler __VtrigSched_h95cd0708__0;
    VlTriggerVec<7> __VstlTriggered;
    VlTriggerVec<9> __VactTriggered;
    VlTriggerVec<9> __VnbaTriggered;

    // INTERNAL VARIABLES
    Vtb__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vtb___024root(Vtb__Syms* symsp, const char* v__name);
    ~Vtb___024root();
    VL_UNCOPYABLE(Vtb___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
