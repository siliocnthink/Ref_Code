// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtb.h for the primary calling header

#include "Vtb__pch.h"
#include "Vtb__Syms.h"
#include "Vtb___024root.h"

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb___024root___dump_triggers__stl(Vtb___024root* vlSelf);
#endif  // VL_DEBUG

VL_ATTR_COLD void Vtb___024root___eval_triggers__stl(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_triggers__stl\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VstlTriggered.set(0U, (IData)(vlSelfRef.__VstlFirstIteration));
    vlSelfRef.__VstlTriggered.set(1U, ((IData)(vlSelfRef.__VassignWtmp_hf6f3e5e5__0) 
                                       != (IData)(vlSelfRef.__Vtrigprevexpr___TOP____VassignWtmp_hf6f3e5e5__0__0)));
    vlSelfRef.__VstlTriggered.set(2U, (vlSelfRef.__VassignWgen_hf9bb11f4__0 
                                       != vlSelfRef.__Vtrigprevexpr___TOP____VassignWgen_hf9bb11f4__0__0));
    vlSelfRef.__VstlTriggered.set(3U, ((IData)(vlSelfRef.__VassignWtmp_he94c6eea__0) 
                                       != (IData)(vlSelfRef.__Vtrigprevexpr___TOP____VassignWtmp_he94c6eea__0__0)));
    vlSelfRef.__VstlTriggered.set(4U, (vlSelfRef.__VassignWgen_hc411ff4f__0 
                                       != vlSelfRef.__Vtrigprevexpr___TOP____VassignWgen_hc411ff4f__0__0));
    vlSelfRef.__VstlTriggered.set(5U, ((IData)(vlSelfRef.__VassignWtmp_h6f72e14a__0) 
                                       != (IData)(vlSelfRef.__Vtrigprevexpr___TOP____VassignWtmp_h6f72e14a__0__0)));
    vlSelfRef.__VstlTriggered.set(6U, (vlSelfRef.__VassignWgen_h05137648__0 
                                       != vlSelfRef.__Vtrigprevexpr___TOP____VassignWgen_h05137648__0__0));
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWtmp_hf6f3e5e5__0__0 
        = vlSelfRef.__VassignWtmp_hf6f3e5e5__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWgen_hf9bb11f4__0__0 
        = vlSelfRef.__VassignWgen_hf9bb11f4__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWtmp_he94c6eea__0__0 
        = vlSelfRef.__VassignWtmp_he94c6eea__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWgen_hc411ff4f__0__0 
        = vlSelfRef.__VassignWgen_hc411ff4f__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWtmp_h6f72e14a__0__0 
        = vlSelfRef.__VassignWtmp_h6f72e14a__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWgen_h05137648__0__0 
        = vlSelfRef.__VassignWgen_h05137648__0;
    if (VL_UNLIKELY((1U & (~ (IData)(vlSelfRef.__VstlDidInit))))) {
        vlSelfRef.__VstlDidInit = 1U;
        vlSelfRef.__VstlTriggered.set(1U, 1U);
        vlSelfRef.__VstlTriggered.set(2U, 1U);
        vlSelfRef.__VstlTriggered.set(3U, 1U);
        vlSelfRef.__VstlTriggered.set(4U, 1U);
        vlSelfRef.__VstlTriggered.set(5U, 1U);
        vlSelfRef.__VstlTriggered.set(6U, 1U);
    }
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vtb___024root___dump_triggers__stl(vlSelf);
    }
#endif
}
