// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_c.h"
#include "Vtb__Syms.h"


void Vtb___024root__trace_chg_0_sub_0(Vtb___024root* vlSelf, VerilatedVcd::Buffer* bufp);

void Vtb___024root__trace_chg_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root__trace_chg_0\n"); );
    // Init
    Vtb___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vtb___024root*>(voidSelf);
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    if (VL_UNLIKELY(!vlSymsp->__Vm_activity)) return;
    // Body
    Vtb___024root__trace_chg_0_sub_0((&vlSymsp->TOP), bufp);
}

void Vtb___024root__trace_chg_0_sub_0(Vtb___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root__trace_chg_0_sub_0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode + 1);
    // Body
    if (VL_UNLIKELY((vlSelfRef.__Vm_traceActivity[1U] 
                     | vlSelfRef.__Vm_traceActivity
                     [2U]))) {
        bufp->chgBit(oldp+0,(vlSelfRef.tb__DOT__rstn));
        bufp->chgBit(oldp+1,(vlSelfRef.tb__DOT__din));
        bufp->chgBit(oldp+2,(vlSelfRef.tb__DOT__cmp_time));
        bufp->chgIData(oldp+3,(vlSelfRef.tb__DOT__cnt),32);
        bufp->chgIData(oldp+4,(vlSelfRef.tb__DOT__dbg),32);
    }
    if (VL_UNLIKELY(vlSelfRef.__Vm_traceActivity[3U])) {
        bufp->chgBit(oldp+5,(vlSelfRef.tb__DOT__chk_sta));
        bufp->chgCData(oldp+6,(vlSelfRef.tb__DOT__u_fsm_chk__DOT__sta),3);
        bufp->chgCData(oldp+7,(vlSelfRef.tb__DOT__u_fsm_chk__DOT__tcnt),7);
        bufp->chgCData(oldp+8,(vlSelfRef.tb__DOT__u_fsm_chk__DOT__ccnt),4);
    }
    bufp->chgBit(oldp+9,(vlSelfRef.tb__DOT__clk));
    bufp->chgBit(oldp+10,(vlSelfRef.tb__DOT__ref_sta__VforceRd));
    bufp->chgBit(oldp+11,(vlSelfRef.tb__DOT__din_buf));
    bufp->chgBit(oldp+12,(vlSelfRef.tb__DOT__chk_sta_buf));
    bufp->chgBit(oldp+13,(vlSelfRef.tb__DOT__ref_sta_buf));
}

void Vtb___024root__trace_cleanup(void* voidSelf, VerilatedVcd* /*unused*/) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root__trace_cleanup\n"); );
    // Init
    Vtb___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vtb___024root*>(voidSelf);
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    vlSymsp->__Vm_activity = false;
    vlSymsp->TOP.__Vm_traceActivity[0U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[1U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[2U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[3U] = 0U;
}
