// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtb.h for the primary calling header

#include "Vtb__pch.h"
#include "Vtb__Syms.h"
#include "Vtb___024root.h"

VL_INLINE_OPT VlCoroutine Vtb___024root___eval_initial__TOP__Vtiming__0(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_initial__TOP__Vtiming__0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ tb__DOT__unnamedblk1_7__DOT____Vrepeat6;
    tb__DOT__unnamedblk1_7__DOT____Vrepeat6 = 0;
    IData/*31:0*/ __Vtask_tb__DOT__give1__2__tb__DOT__unnamedblk1_2__DOT____Vrepeat1;
    __Vtask_tb__DOT__give1__2__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0;
    IData/*31:0*/ __Vtask_tb__DOT__give1__4__tb__DOT__unnamedblk1_2__DOT____Vrepeat1;
    __Vtask_tb__DOT__give1__4__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0;
    IData/*31:0*/ __Vtask_tb__DOT__give1__5__tb__DOT__unnamedblk1_2__DOT____Vrepeat1;
    __Vtask_tb__DOT__give1__5__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0;
    IData/*31:0*/ __Vtask_tb__DOT__give1__6__tb__DOT__unnamedblk1_2__DOT____Vrepeat1;
    __Vtask_tb__DOT__give1__6__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0;
    IData/*31:0*/ __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1;
    __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0;
    IData/*31:0*/ __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1;
    __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0;
    IData/*31:0*/ __Vtask_tb__DOT__give1__12__tb__DOT__unnamedblk1_2__DOT____Vrepeat1;
    __Vtask_tb__DOT__give1__12__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0;
    // Body
    vlSymsp->_vm_contextp__->dumpfile(std::string{"tb.vcd"});
    vlSymsp->_traceDumpOpen();
    vlSelfRef.tb__DOT__ref_sta__VforceEn = 0U;
    vlSelfRef.tb__DOT__dbg = 0U;
    vlSelfRef.tb__DOT__clk = 0U;
    vlSelfRef.tb__DOT__rstn = 1U;
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__din = 0U;
    vlSelfRef.tb__DOT__cmp_time = 0U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         72);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         72);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         72);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         72);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         72);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         72);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         72);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         72);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         72);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         72);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         72);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__rstn = 0U;
    vlSelfRef.tb__DOT__cmp_time = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         73);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         73);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         73);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         73);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         73);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         73);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         73);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         73);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         73);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         73);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         73);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__rstn = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         77);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         77);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         77);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         77);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         77);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         78);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         79);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         79);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         79);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         79);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         79);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         79);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         79);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         79);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         79);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         79);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         79);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         79);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         79);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         79);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         79);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    tb__DOT__unnamedblk1_7__DOT____Vrepeat6 = 0x64U;
    while (VL_LTS_III(32, 0U, tb__DOT__unnamedblk1_7__DOT____Vrepeat6)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             80);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        tb__DOT__unnamedblk1_7__DOT____Vrepeat6 = (tb__DOT__unnamedblk1_7__DOT____Vrepeat6 
                                                   - (IData)(1U));
    }
    vlSelfRef.tb__DOT__dbg = 1U;
    vlSelfRef.tb__DOT__ref_sta = 0U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         82);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         82);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         82);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         82);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         82);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         82);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         82);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         82);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         82);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         82);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         82);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         82);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         82);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         82);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         82);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__dbg = 2U;
    vlSelfRef.tb__DOT__din = 0U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         50);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 0U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__dbg = 3U;
    vlSelfRef.tb__DOT__din = 0U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         50);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 0U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__dbg = 4U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__2__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__2__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__2__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__2__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__dbg = 5U;
    vlSelfRef.tb__DOT__din = 0U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         50);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 0U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__dbg = 6U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__4__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__4__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__4__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__4__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__5__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__5__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__5__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__5__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__6__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__6__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__6__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__6__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__din = 0U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         50);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 0U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__dbg = 7U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 1U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 2U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 3U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 4U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 5U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 6U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 7U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 8U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__8__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 9U;
    vlSelfRef.tb__DOT__din = 0U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         50);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 0U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__dbg = 8U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 1U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 2U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 3U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 4U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 5U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 6U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 7U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 8U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 9U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__10__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    vlSelfRef.tb__DOT__cnt = 0xaU;
    vlSelfRef.tb__DOT__ref_sta__VforceEn = 1U;
    vlSelfRef.tb__DOT__ref_sta__VforceVal = 1U;
    vlSelfRef.tb__DOT__ref_sta__VforceRd = 1U;
    vlSelfRef.tb__DOT__din = 0U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         50);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 0U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__din = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__ref_sta = 1U;
    __Vtask_tb__DOT__give1__12__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 = 0x64U;
    while (VL_LTS_III(32, 0U, __Vtask_tb__DOT__give1__12__tb__DOT__unnamedblk1_2__DOT____Vrepeat1)) {
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             59);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__give1__12__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
            = (__Vtask_tb__DOT__give1__12__tb__DOT__unnamedblk1_2__DOT____Vrepeat1 
               - (IData)(1U));
    }
    vlSelfRef.tb__DOT__ref_sta = 0U;
    VL_WRITEF_NX("Sim Pass.\n",0);
    VL_FINISH_MT("../pattern/tb.v", 124, "");
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb___024root___dump_triggers__act(Vtb___024root* vlSelf);
#endif  // VL_DEBUG

void Vtb___024root___eval_triggers__act(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_triggers__act\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VactTriggered.set(0U, ((IData)(vlSelfRef.__VassignWtmp_hf6f3e5e5__0) 
                                       != (IData)(vlSelfRef.__Vtrigprevexpr___TOP____VassignWtmp_hf6f3e5e5__0__1)));
    vlSelfRef.__VactTriggered.set(1U, (vlSelfRef.__VassignWgen_hf9bb11f4__0 
                                       != vlSelfRef.__Vtrigprevexpr___TOP____VassignWgen_hf9bb11f4__0__1));
    vlSelfRef.__VactTriggered.set(2U, ((IData)(vlSelfRef.__VassignWtmp_he94c6eea__0) 
                                       != (IData)(vlSelfRef.__Vtrigprevexpr___TOP____VassignWtmp_he94c6eea__0__1)));
    vlSelfRef.__VactTriggered.set(3U, (vlSelfRef.__VassignWgen_hc411ff4f__0 
                                       != vlSelfRef.__Vtrigprevexpr___TOP____VassignWgen_hc411ff4f__0__1));
    vlSelfRef.__VactTriggered.set(4U, ((IData)(vlSelfRef.__VassignWtmp_h6f72e14a__0) 
                                       != (IData)(vlSelfRef.__Vtrigprevexpr___TOP____VassignWtmp_h6f72e14a__0__1)));
    vlSelfRef.__VactTriggered.set(5U, (vlSelfRef.__VassignWgen_h05137648__0 
                                       != vlSelfRef.__Vtrigprevexpr___TOP____VassignWgen_h05137648__0__1));
    vlSelfRef.__VactTriggered.set(6U, ((IData)(vlSelfRef.tb__DOT__clk) 
                                       & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP__tb__DOT__clk__0))));
    vlSelfRef.__VactTriggered.set(7U, ((~ (IData)(vlSelfRef.tb__DOT__rstn)) 
                                       & (IData)(vlSelfRef.__Vtrigprevexpr___TOP__tb__DOT__rstn__0)));
    vlSelfRef.__VactTriggered.set(8U, vlSelfRef.__VdlySched.awaitingCurrentTime());
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWtmp_hf6f3e5e5__0__1 
        = vlSelfRef.__VassignWtmp_hf6f3e5e5__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWgen_hf9bb11f4__0__1 
        = vlSelfRef.__VassignWgen_hf9bb11f4__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWtmp_he94c6eea__0__1 
        = vlSelfRef.__VassignWtmp_he94c6eea__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWgen_hc411ff4f__0__1 
        = vlSelfRef.__VassignWgen_hc411ff4f__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWtmp_h6f72e14a__0__1 
        = vlSelfRef.__VassignWtmp_h6f72e14a__0;
    vlSelfRef.__Vtrigprevexpr___TOP____VassignWgen_h05137648__0__1 
        = vlSelfRef.__VassignWgen_h05137648__0;
    vlSelfRef.__Vtrigprevexpr___TOP__tb__DOT__clk__0 
        = vlSelfRef.tb__DOT__clk;
    vlSelfRef.__Vtrigprevexpr___TOP__tb__DOT__rstn__0 
        = vlSelfRef.tb__DOT__rstn;
    if (VL_UNLIKELY((1U & (~ (IData)(vlSelfRef.__VactDidInit))))) {
        vlSelfRef.__VactDidInit = 1U;
        vlSelfRef.__VactTriggered.set(0U, 1U);
        vlSelfRef.__VactTriggered.set(1U, 1U);
        vlSelfRef.__VactTriggered.set(2U, 1U);
        vlSelfRef.__VactTriggered.set(3U, 1U);
        vlSelfRef.__VactTriggered.set(4U, 1U);
        vlSelfRef.__VactTriggered.set(5U, 1U);
    }
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vtb___024root___dump_triggers__act(vlSelf);
    }
#endif
}
