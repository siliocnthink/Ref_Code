// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_c.h"
#include "Vtb__Syms.h"


void Vtb___024root__trace_chg_0_sub_0(Vtb___024root* vlSelf, VerilatedVcd::Buffer* bufp);

void Vtb___024root__trace_chg_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root__trace_chg_0\n"); );
    // Init
    Vtb___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vtb___024root*>(voidSelf);
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    if (VL_UNLIKELY(!vlSymsp->__Vm_activity)) return;
    // Body
    Vtb___024root__trace_chg_0_sub_0((&vlSymsp->TOP), bufp);
}

void Vtb___024root__trace_chg_0_sub_0(Vtb___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root__trace_chg_0_sub_0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode + 1);
    // Body
    if (VL_UNLIKELY((vlSelfRef.__Vm_traceActivity[1U] 
                     | vlSelfRef.__Vm_traceActivity
                     [2U]))) {
        bufp->chgBit(oldp+0,(vlSelfRef.tb__DOT__rstn));
        bufp->chgBit(oldp+1,(vlSelfRef.tb__DOT__en));
        bufp->chgBit(oldp+2,(vlSelfRef.tb__DOT__din));
        bufp->chgCData(oldp+3,(vlSelfRef.tb__DOT__pt_in),8);
        bufp->chgIData(oldp+4,(vlSelfRef.tb__DOT__tcnt0),32);
        bufp->chgCData(oldp+5,(vlSelfRef.tb__DOT__out_pt__Vstatic__cnt),4);
        bufp->chgCData(oldp+6,(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data),8);
    }
    if (VL_UNLIKELY(vlSelfRef.__Vm_traceActivity[3U])) {
        bufp->chgCData(oldp+7,((((IData)(vlSelfRef.tb__DOT____Vcellout__u1_detect__match) 
                                 << 1U) | (IData)(vlSelfRef.tb__DOT____Vcellout__u0_detect__match))),2);
        bufp->chgBit(oldp+8,(vlSelfRef.tb__DOT____Vcellout__u0_detect__match));
        bufp->chgCData(oldp+9,(vlSelfRef.tb__DOT__u0_detect__DOT__sta),2);
        bufp->chgBit(oldp+10,(vlSelfRef.tb__DOT____Vcellout__u1_detect__match));
        bufp->chgCData(oldp+11,(vlSelfRef.tb__DOT__u1_detect__DOT__sf_reg),3);
    }
    bufp->chgBit(oldp+12,(vlSelfRef.tb__DOT__clk));
    bufp->chgCData(oldp+13,(vlSelfRef.tb__DOT__u0_detect__DOT__nsta),2);
}

void Vtb___024root__trace_cleanup(void* voidSelf, VerilatedVcd* /*unused*/) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root__trace_cleanup\n"); );
    // Init
    Vtb___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vtb___024root*>(voidSelf);
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    vlSymsp->__Vm_activity = false;
    vlSymsp->TOP.__Vm_traceActivity[0U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[1U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[2U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[3U] = 0U;
}
