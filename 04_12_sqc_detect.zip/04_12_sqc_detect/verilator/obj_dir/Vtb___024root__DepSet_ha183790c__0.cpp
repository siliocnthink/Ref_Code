// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtb.h for the primary calling header

#include "Vtb__pch.h"
#include "Vtb___024root.h"

VL_ATTR_COLD void Vtb___024root___eval_initial__TOP(Vtb___024root* vlSelf);
VlCoroutine Vtb___024root___eval_initial__TOP__Vtiming__0(Vtb___024root* vlSelf);
VlCoroutine Vtb___024root___eval_initial__TOP__Vtiming__1(Vtb___024root* vlSelf);

void Vtb___024root___eval_initial(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_initial\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    Vtb___024root___eval_initial__TOP(vlSelf);
    vlSelfRef.__Vm_traceActivity[1U] = 1U;
    Vtb___024root___eval_initial__TOP__Vtiming__0(vlSelf);
    Vtb___024root___eval_initial__TOP__Vtiming__1(vlSelf);
    vlSelfRef.__Vtrigprevexpr___TOP__tb__DOT__clk__0 
        = vlSelfRef.tb__DOT__clk;
    vlSelfRef.__Vtrigprevexpr___TOP__tb__DOT__rstn__0 
        = vlSelfRef.tb__DOT__rstn;
}

VL_INLINE_OPT VlCoroutine Vtb___024root___eval_initial__TOP__Vtiming__0(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_initial__TOP__Vtiming__0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*7:0*/ __Vtask_tb__DOT__out_pt__0__data;
    __Vtask_tb__DOT__out_pt__0__data = 0;
    CData/*0:0*/ __Vtask_tb__DOT__out_pt__0__en_rand;
    __Vtask_tb__DOT__out_pt__0__en_rand = 0;
    CData/*7:0*/ __Vtask_tb__DOT__out_pt__1__data;
    __Vtask_tb__DOT__out_pt__1__data = 0;
    CData/*0:0*/ __Vtask_tb__DOT__out_pt__1__en_rand;
    __Vtask_tb__DOT__out_pt__1__en_rand = 0;
    CData/*7:0*/ __Vtask_tb__DOT__out_pt__2__data;
    __Vtask_tb__DOT__out_pt__2__data = 0;
    CData/*0:0*/ __Vtask_tb__DOT__out_pt__2__en_rand;
    __Vtask_tb__DOT__out_pt__2__en_rand = 0;
    CData/*7:0*/ __Vtask_tb__DOT__out_pt__3__data;
    __Vtask_tb__DOT__out_pt__3__data = 0;
    CData/*0:0*/ __Vtask_tb__DOT__out_pt__3__en_rand;
    __Vtask_tb__DOT__out_pt__3__en_rand = 0;
    CData/*7:0*/ __Vtask_tb__DOT__out_pt__4__data;
    __Vtask_tb__DOT__out_pt__4__data = 0;
    CData/*0:0*/ __Vtask_tb__DOT__out_pt__4__en_rand;
    __Vtask_tb__DOT__out_pt__4__en_rand = 0;
    CData/*7:0*/ __Vtask_tb__DOT__out_pt__5__data;
    __Vtask_tb__DOT__out_pt__5__data = 0;
    CData/*0:0*/ __Vtask_tb__DOT__out_pt__5__en_rand;
    __Vtask_tb__DOT__out_pt__5__en_rand = 0;
    // Body
    vlSelfRef.tb__DOT__clk = 0U;
    vlSelfRef.tb__DOT__rstn = 0U;
    vlSelfRef.tb__DOT__en = 0U;
    vlSelfRef.tb__DOT__pt_in = 0U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         48);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         49);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         49);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         49);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         49);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         49);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         49);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__rstn = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         51);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__en = 1U;
    vlSelfRef.tb__DOT__pt_in = 0xb6U;
    __Vtask_tb__DOT__out_pt__0__en_rand = 0U;
    __Vtask_tb__DOT__out_pt__0__data = vlSelfRef.tb__DOT__pt_in;
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = __Vtask_tb__DOT__out_pt__0__data;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__0__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 1U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__0__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 2U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__0__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 3U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__0__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 4U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__0__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 5U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__0__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 6U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__0__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    if (__Vtask_tb__DOT__out_pt__0__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 7U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 8U;
    vlSelfRef.tb__DOT__en = 1U;
    vlSelfRef.tb__DOT__pt_in = 0xf6U;
    __Vtask_tb__DOT__out_pt__1__en_rand = 0U;
    __Vtask_tb__DOT__out_pt__1__data = vlSelfRef.tb__DOT__pt_in;
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = __Vtask_tb__DOT__out_pt__1__data;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__1__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 1U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__1__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 2U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__1__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 3U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__1__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 4U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__1__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 5U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__1__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 6U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__1__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    if (__Vtask_tb__DOT__out_pt__1__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 7U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 8U;
    vlSelfRef.tb__DOT__en = 1U;
    vlSelfRef.tb__DOT__pt_in = 0x8bU;
    __Vtask_tb__DOT__out_pt__2__en_rand = 0U;
    __Vtask_tb__DOT__out_pt__2__data = vlSelfRef.tb__DOT__pt_in;
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = __Vtask_tb__DOT__out_pt__2__data;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__2__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 1U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__2__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 2U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__2__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 3U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__2__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 4U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__2__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 5U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__2__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 6U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__2__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    if (__Vtask_tb__DOT__out_pt__2__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 7U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 8U;
    vlSelfRef.tb__DOT__en = 1U;
    vlSelfRef.tb__DOT__pt_in = 0xabU;
    __Vtask_tb__DOT__out_pt__3__en_rand = 0U;
    __Vtask_tb__DOT__out_pt__3__data = vlSelfRef.tb__DOT__pt_in;
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = __Vtask_tb__DOT__out_pt__3__data;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__3__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 1U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__3__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 2U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__3__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 3U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__3__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 4U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__3__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 5U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__3__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 6U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    if (__Vtask_tb__DOT__out_pt__3__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    if (__Vtask_tb__DOT__out_pt__3__en_rand) {
        vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
    }
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 7U;
    vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                    >> 7U));
    vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data = (
                                                   (0xfeU 
                                                    & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                                         >> 7U)));
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VdlySched.delay(0xaULL, nullptr, 
                                         "../pattern/tb.v", 
                                         40);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 8U;
    vlSelfRef.tb__DOT__tcnt0 = 0U;
    while (VL_GTS_III(32, 0x3e8U, vlSelfRef.tb__DOT__tcnt0)) {
        vlSelfRef.tb__DOT__pt_in = (VL_GTS_III(32, 0xfaU, vlSelfRef.tb__DOT__tcnt0)
                                     ? 0xabU : (VL_GTS_III(32, 0x1f4U, vlSelfRef.tb__DOT__tcnt0)
                                                 ? 0x8bU
                                                 : 
                                                (VL_GTS_III(32, 0x2eeU, vlSelfRef.tb__DOT__tcnt0)
                                                  ? 0xf6U
                                                  : 0xb6U)));
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             80);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        co_await vlSelfRef.__VdlySched.delay(0xaULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             80);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__out_pt__4__en_rand = 1U;
        __Vtask_tb__DOT__out_pt__4__data = vlSelfRef.tb__DOT__pt_in;
        vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data 
            = __Vtask_tb__DOT__out_pt__4__data;
        vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                        >> 7U));
        vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data 
            = ((0xfeU & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                         << 1U)) | (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                          >> 7U)));
        if (__Vtask_tb__DOT__out_pt__4__en_rand) {
            vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
        }
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        co_await vlSelfRef.__VdlySched.delay(0xaULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 1U;
        vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                        >> 7U));
        vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data 
            = ((0xfeU & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                         << 1U)) | (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                          >> 7U)));
        if (__Vtask_tb__DOT__out_pt__4__en_rand) {
            vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
        }
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        co_await vlSelfRef.__VdlySched.delay(0xaULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 2U;
        vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                        >> 7U));
        vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data 
            = ((0xfeU & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                         << 1U)) | (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                          >> 7U)));
        if (__Vtask_tb__DOT__out_pt__4__en_rand) {
            vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
        }
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        co_await vlSelfRef.__VdlySched.delay(0xaULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 3U;
        vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                        >> 7U));
        vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data 
            = ((0xfeU & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                         << 1U)) | (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                          >> 7U)));
        if (__Vtask_tb__DOT__out_pt__4__en_rand) {
            vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
        }
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        co_await vlSelfRef.__VdlySched.delay(0xaULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 4U;
        vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                        >> 7U));
        vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data 
            = ((0xfeU & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                         << 1U)) | (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                          >> 7U)));
        if (__Vtask_tb__DOT__out_pt__4__en_rand) {
            vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
        }
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        co_await vlSelfRef.__VdlySched.delay(0xaULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 5U;
        vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                        >> 7U));
        vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data 
            = ((0xfeU & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                         << 1U)) | (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                          >> 7U)));
        if (__Vtask_tb__DOT__out_pt__4__en_rand) {
            vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
        }
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        co_await vlSelfRef.__VdlySched.delay(0xaULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 6U;
        vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                        >> 7U));
        vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data 
            = ((0xfeU & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                         << 1U)) | (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                          >> 7U)));
        if (__Vtask_tb__DOT__out_pt__4__en_rand) {
            vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
        }
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        co_await vlSelfRef.__VdlySched.delay(0xaULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             40);
        if (__Vtask_tb__DOT__out_pt__4__en_rand) {
            vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
        }
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 7U;
        vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                        >> 7U));
        vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data 
            = ((0xfeU & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                         << 1U)) | (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                          >> 7U)));
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        co_await vlSelfRef.__VdlySched.delay(0xaULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 8U;
        vlSelfRef.tb__DOT__tcnt0 = ((IData)(1U) + vlSelfRef.tb__DOT__tcnt0);
    }
    vlSelfRef.tb__DOT__tcnt0 = 0U;
    while (VL_GTS_III(32, 0x3e8U, vlSelfRef.tb__DOT__tcnt0)) {
        vlSelfRef.tb__DOT__pt_in = (0xffU & VL_MODDIVS_III(32, (IData)(
                                                                       VL_RANDOM_I()), (IData)(0x100U)));
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             88);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        co_await vlSelfRef.__VdlySched.delay(0xaULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             88);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        __Vtask_tb__DOT__out_pt__5__en_rand = 1U;
        __Vtask_tb__DOT__out_pt__5__data = vlSelfRef.tb__DOT__pt_in;
        vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data 
            = __Vtask_tb__DOT__out_pt__5__data;
        vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                        >> 7U));
        vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data 
            = ((0xfeU & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                         << 1U)) | (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                          >> 7U)));
        if (__Vtask_tb__DOT__out_pt__5__en_rand) {
            vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
        }
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        co_await vlSelfRef.__VdlySched.delay(0xaULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 1U;
        vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                        >> 7U));
        vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data 
            = ((0xfeU & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                         << 1U)) | (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                          >> 7U)));
        if (__Vtask_tb__DOT__out_pt__5__en_rand) {
            vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
        }
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        co_await vlSelfRef.__VdlySched.delay(0xaULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 2U;
        vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                        >> 7U));
        vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data 
            = ((0xfeU & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                         << 1U)) | (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                          >> 7U)));
        if (__Vtask_tb__DOT__out_pt__5__en_rand) {
            vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
        }
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        co_await vlSelfRef.__VdlySched.delay(0xaULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 3U;
        vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                        >> 7U));
        vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data 
            = ((0xfeU & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                         << 1U)) | (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                          >> 7U)));
        if (__Vtask_tb__DOT__out_pt__5__en_rand) {
            vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
        }
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        co_await vlSelfRef.__VdlySched.delay(0xaULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 4U;
        vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                        >> 7U));
        vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data 
            = ((0xfeU & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                         << 1U)) | (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                          >> 7U)));
        if (__Vtask_tb__DOT__out_pt__5__en_rand) {
            vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
        }
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        co_await vlSelfRef.__VdlySched.delay(0xaULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 5U;
        vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                        >> 7U));
        vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data 
            = ((0xfeU & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                         << 1U)) | (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                          >> 7U)));
        if (__Vtask_tb__DOT__out_pt__5__en_rand) {
            vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
        }
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        co_await vlSelfRef.__VdlySched.delay(0xaULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 6U;
        vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                        >> 7U));
        vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data 
            = ((0xfeU & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                         << 1U)) | (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                          >> 7U)));
        if (__Vtask_tb__DOT__out_pt__5__en_rand) {
            vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
        }
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        co_await vlSelfRef.__VdlySched.delay(0xaULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             40);
        if (__Vtask_tb__DOT__out_pt__5__en_rand) {
            vlSelfRef.tb__DOT__en = (1U & VL_RANDOM_I());
        }
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 7U;
        vlSelfRef.tb__DOT__din = (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                        >> 7U));
        vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data 
            = ((0xfeU & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                         << 1U)) | (1U & ((IData)(vlSelfRef.tb__DOT__out_pt__Vstatic__sf_data) 
                                          >> 7U)));
        co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                             nullptr, 
                                                             "@(posedge tb.clk)", 
                                                             "../pattern/tb.v", 
                                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        co_await vlSelfRef.__VdlySched.delay(0xaULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             40);
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        vlSelfRef.tb__DOT__out_pt__Vstatic__cnt = 8U;
        vlSelfRef.tb__DOT__tcnt0 = ((IData)(1U) + vlSelfRef.tb__DOT__tcnt0);
    }
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         92);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         92);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         92);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         92);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         92);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         92);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         92);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         92);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         92);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    co_await vlSelfRef.__VtrigSched_h95cd0708__0.trigger(0U, 
                                                         nullptr, 
                                                         "@(posedge tb.clk)", 
                                                         "../pattern/tb.v", 
                                                         92);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    VL_FINISH_MT("../pattern/tb.v", 93, "");
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
}

VL_INLINE_OPT VlCoroutine Vtb___024root___eval_initial__TOP__Vtiming__1(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_initial__TOP__Vtiming__1\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    while (1U) {
        co_await vlSelfRef.__VdlySched.delay(0x32ULL, 
                                             nullptr, 
                                             "../pattern/tb.v", 
                                             23);
        vlSelfRef.tb__DOT__clk = (1U & (~ (IData)(vlSelfRef.tb__DOT__clk)));
    }
}

void Vtb___024root___act_comb__TOP__0(Vtb___024root* vlSelf);

void Vtb___024root___eval_act(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_act\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((5ULL & vlSelfRef.__VactTriggered.word(0U))) {
        Vtb___024root___act_comb__TOP__0(vlSelf);
    }
}

extern const VlUnpacked<CData/*1:0*/, 16> Vtb__ConstPool__TABLE_hd3c95ce3_0;

VL_INLINE_OPT void Vtb___024root___act_comb__TOP__0(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___act_comb__TOP__0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*3:0*/ __Vtableidx1;
    __Vtableidx1 = 0;
    // Body
    __Vtableidx1 = (((IData)(vlSelfRef.tb__DOT__din) 
                     << 3U) | (((IData)(vlSelfRef.tb__DOT__en) 
                                << 2U) | (IData)(vlSelfRef.tb__DOT__u0_detect__DOT__sta)));
    vlSelfRef.tb__DOT__u0_detect__DOT__nsta = Vtb__ConstPool__TABLE_hd3c95ce3_0
        [__Vtableidx1];
}

void Vtb___024root___nba_sequent__TOP__0(Vtb___024root* vlSelf);
void Vtb___024root___nba_sequent__TOP__1(Vtb___024root* vlSelf);

void Vtb___024root___eval_nba(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_nba\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        Vtb___024root___nba_sequent__TOP__0(vlSelf);
    }
    if ((3ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        Vtb___024root___nba_sequent__TOP__1(vlSelf);
        vlSelfRef.__Vm_traceActivity[3U] = 1U;
    }
    if ((7ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        Vtb___024root___act_comb__TOP__0(vlSelf);
    }
}

VL_INLINE_OPT void Vtb___024root___nba_sequent__TOP__0(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___nba_sequent__TOP__0\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.tb__DOT__rstn) {
        if (VL_UNLIKELY(((IData)(vlSelfRef.tb__DOT____Vcellout__u0_detect__match) 
                         != (IData)(vlSelfRef.tb__DOT____Vcellout__u1_detect__match)))) {
            VL_WRITEF_NX("Error: Find sequency error.\n\n",0);
            VL_STOP_MT("../pattern/tb.v", 120, "");
        }
    }
}

VL_INLINE_OPT void Vtb___024root___nba_sequent__TOP__1(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___nba_sequent__TOP__1\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __Vdly__tb__DOT____Vcellout__u0_detect__match;
    __Vdly__tb__DOT____Vcellout__u0_detect__match = 0;
    CData/*2:0*/ __Vdly__tb__DOT__u1_detect__DOT__sf_reg;
    __Vdly__tb__DOT__u1_detect__DOT__sf_reg = 0;
    CData/*0:0*/ __Vdly__tb__DOT____Vcellout__u1_detect__match;
    __Vdly__tb__DOT____Vcellout__u1_detect__match = 0;
    // Body
    __Vdly__tb__DOT__u1_detect__DOT__sf_reg = vlSelfRef.tb__DOT__u1_detect__DOT__sf_reg;
    __Vdly__tb__DOT____Vcellout__u1_detect__match = vlSelfRef.tb__DOT____Vcellout__u1_detect__match;
    __Vdly__tb__DOT____Vcellout__u0_detect__match = vlSelfRef.tb__DOT____Vcellout__u0_detect__match;
    if (vlSelfRef.tb__DOT__rstn) {
        if ((((IData)(vlSelfRef.tb__DOT__en) & (5U 
                                                == (IData)(vlSelfRef.tb__DOT__u1_detect__DOT__sf_reg))) 
             & (IData)(vlSelfRef.tb__DOT__din))) {
            __Vdly__tb__DOT____Vcellout__u1_detect__match = 1U;
        } else if (vlSelfRef.tb__DOT____Vcellout__u1_detect__match) {
            __Vdly__tb__DOT____Vcellout__u1_detect__match = 0U;
        }
        if ((((IData)(vlSelfRef.tb__DOT__en) & (3U 
                                                == (IData)(vlSelfRef.tb__DOT__u0_detect__DOT__sta))) 
             & (IData)(vlSelfRef.tb__DOT__din))) {
            __Vdly__tb__DOT____Vcellout__u0_detect__match = 1U;
        } else if (vlSelfRef.tb__DOT____Vcellout__u0_detect__match) {
            __Vdly__tb__DOT____Vcellout__u0_detect__match = 0U;
        }
        if (vlSelfRef.tb__DOT__en) {
            __Vdly__tb__DOT__u1_detect__DOT__sf_reg 
                = ((6U & ((IData)(vlSelfRef.tb__DOT__u1_detect__DOT__sf_reg) 
                          << 1U)) | (IData)(vlSelfRef.tb__DOT__din));
            vlSelfRef.tb__DOT__u0_detect__DOT__sta 
                = vlSelfRef.tb__DOT__u0_detect__DOT__nsta;
        }
    } else {
        __Vdly__tb__DOT__u1_detect__DOT__sf_reg = 0U;
        __Vdly__tb__DOT____Vcellout__u1_detect__match = 0U;
        __Vdly__tb__DOT____Vcellout__u0_detect__match = 0U;
        vlSelfRef.tb__DOT__u0_detect__DOT__sta = 0U;
    }
    vlSelfRef.tb__DOT__u1_detect__DOT__sf_reg = __Vdly__tb__DOT__u1_detect__DOT__sf_reg;
    vlSelfRef.tb__DOT____Vcellout__u1_detect__match 
        = __Vdly__tb__DOT____Vcellout__u1_detect__match;
    vlSelfRef.tb__DOT____Vcellout__u0_detect__match 
        = __Vdly__tb__DOT____Vcellout__u0_detect__match;
}

void Vtb___024root___timing_resume(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___timing_resume\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VactTriggered.word(0U))) {
        vlSelfRef.__VtrigSched_h95cd0708__0.resume(
                                                   "@(posedge tb.clk)");
    }
    if ((4ULL & vlSelfRef.__VactTriggered.word(0U))) {
        vlSelfRef.__VdlySched.resume();
    }
}

void Vtb___024root___timing_commit(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___timing_commit\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((! (1ULL & vlSelfRef.__VactTriggered.word(0U)))) {
        vlSelfRef.__VtrigSched_h95cd0708__0.commit(
                                                   "@(posedge tb.clk)");
    }
}

void Vtb___024root___eval_triggers__act(Vtb___024root* vlSelf);

bool Vtb___024root___eval_phase__act(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_phase__act\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    VlTriggerVec<3> __VpreTriggered;
    CData/*0:0*/ __VactExecute;
    // Body
    Vtb___024root___eval_triggers__act(vlSelf);
    Vtb___024root___timing_commit(vlSelf);
    __VactExecute = vlSelfRef.__VactTriggered.any();
    if (__VactExecute) {
        __VpreTriggered.andNot(vlSelfRef.__VactTriggered, vlSelfRef.__VnbaTriggered);
        vlSelfRef.__VnbaTriggered.thisOr(vlSelfRef.__VactTriggered);
        Vtb___024root___timing_resume(vlSelf);
        Vtb___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Vtb___024root___eval_phase__nba(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_phase__nba\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = vlSelfRef.__VnbaTriggered.any();
    if (__VnbaExecute) {
        Vtb___024root___eval_nba(vlSelf);
        vlSelfRef.__VnbaTriggered.clear();
    }
    return (__VnbaExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb___024root___dump_triggers__nba(Vtb___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb___024root___dump_triggers__act(Vtb___024root* vlSelf);
#endif  // VL_DEBUG

void Vtb___024root___eval(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ __VnbaIterCount;
    CData/*0:0*/ __VnbaContinue;
    // Body
    __VnbaIterCount = 0U;
    __VnbaContinue = 1U;
    while (__VnbaContinue) {
        if (VL_UNLIKELY((0x64U < __VnbaIterCount))) {
#ifdef VL_DEBUG
            Vtb___024root___dump_triggers__nba(vlSelf);
#endif
            VL_FATAL_MT("../pattern/tb.v", 4, "", "NBA region did not converge.");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        __VnbaContinue = 0U;
        vlSelfRef.__VactIterCount = 0U;
        vlSelfRef.__VactContinue = 1U;
        while (vlSelfRef.__VactContinue) {
            if (VL_UNLIKELY((0x64U < vlSelfRef.__VactIterCount))) {
#ifdef VL_DEBUG
                Vtb___024root___dump_triggers__act(vlSelf);
#endif
                VL_FATAL_MT("../pattern/tb.v", 4, "", "Active region did not converge.");
            }
            vlSelfRef.__VactIterCount = ((IData)(1U) 
                                         + vlSelfRef.__VactIterCount);
            vlSelfRef.__VactContinue = 0U;
            if (Vtb___024root___eval_phase__act(vlSelf)) {
                vlSelfRef.__VactContinue = 1U;
            }
        }
        if (Vtb___024root___eval_phase__nba(vlSelf)) {
            __VnbaContinue = 1U;
        }
    }
}

#ifdef VL_DEBUG
void Vtb___024root___eval_debug_assertions(Vtb___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb___024root___eval_debug_assertions\n"); );
    auto& vlSelfRef = std::ref(*vlSelf).get();
}
#endif  // VL_DEBUG
